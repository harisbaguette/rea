# 입어봄 시작하기

공통 화면은 studio/README.md를 따라 실행한다. Mac은 studio/start-macos.command, Windows는 studio/start-windows.cmd도 사용할 수 있다. Node.js 22.12 이상이 필요하다.

AI 추론 서버·GPU 모델은 포함되지 않는다. Windows에서 CONTINUE_WINDOWS.md의 지시로 이어서 진행한다. 작업 순서는 WINDOWS_PLAN.md, 서버 규격은 API_CONTRACT.md에 있다.

node_modules는 포함하지 않는다. Windows와 Mac에서 각각 studio/의 npm ci로 설치한다. 개인 사진이나 토큰은 포함하지 않는다.
